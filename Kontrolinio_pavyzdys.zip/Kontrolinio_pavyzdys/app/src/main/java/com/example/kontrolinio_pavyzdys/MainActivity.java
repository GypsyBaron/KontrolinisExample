package com.example.kontrolinio_pavyzdys;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.SearchManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    final Random random = new Random();
    private int delay;
    private int min, max;
    private int randomNumber;

    final Handler handler = new Handler();
    final Runnable task = new Runnable() {
        @SuppressLint("SetTextI18n")
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public void run() {
            randomNumber = random.nextInt((max - min) + 1) + min;
            if (!handler.hasCallbacks(this)) {
                handler.postDelayed(this, delay);
            }
            TextView text = (TextView) findViewById(R.id.text);
            text.setText(Integer.toString(randomNumber));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.delay = 500;
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void startFirstRandomGenerator(View view) {
        this.min = -100;
        this.max = 0;
        this.task.run();
    }

    public void endFirstRandomGenerator(View view) {
        handler.removeCallbacks(task);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void startSecondRandomGenerator(View view) {
        this.min = 0;
        this.max = 100;
        this.task.run();
    }

    public void endSecondRandomGenerator(View view) {
        this.handler.removeCallbacks(task);
        googleSearch(view);
    }

    public void googleSearch(View view) {
        Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
        intent.putExtra(SearchManager.QUERY, Integer.toString(randomNumber));
        startActivity(intent);
    }
}
